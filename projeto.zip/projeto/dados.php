<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado - Formulário</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">

    <?php
        $endereco = $_GET["2campo"];
        $desc = $_GET["3campo"];
        $prop = $_GET["4campo"];
        $datacad = $_GET["5campo"];
    ?>
</head>

<body>
    <?php   
        
        if($endereco == "" || $desc == "" || $prop == "" || $datacad == "")
        {
            echo ("<p>Um dos campos está vazio!!</p>");
            echo ("Por favor refaça o formulário");
        }
        else 
        {
            echo ('Endereço: ' . $endereco);
            echo ('<br>Descrição: ' . $desc);
            echo ('<br>Proprietário: ' . $prop);
            echo ('<br>Data do Cadastramento: ' . $datacad);
        }



    ?>
</body>

</html>