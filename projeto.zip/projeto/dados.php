<!DOCTYPE html>
<html lang="pr-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado - Formulário</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Oswald'>
    <script src="bootstrap-5.3.3-dist/js/bootstrap.min.js"></script>

    <?php
        $endereco = $_GET["2campo"];
        $desc = $_GET["3campo"];
        $prop = $_GET["4campo"];
        $datacad = $_GET["5campo"];
    ?>
</head>

<body>
    
    <div class="navbar p-0">
        <button class="btn xbtn rounded-top rounded-0"><img src="imagens/catatau.png" width="40" height="55"></button>
        <div><h1>CATATAU</h1></div>
    </div>
    
    <?php   
        
        if($endereco == "" || $desc == "" || $prop == "" || $datacad == "")
        {
            echo ("<p>Um dos campos está vazio!!</p>");
            echo ("Por favor refaça o formulário");
        }
        else 
        {
            
            echo ('<div class="container mt-4 border border-black shadow shadow-4">');    
            echo ('<ul class="list-group"');
            echo ('<br><li class="list-group-item mt-3 border border-warning"><b>Endereço:</b> ' . $endereco . "</li>");
            echo ('<br><li class="list-group-item mt-3 border border-warning"><b>Descrição: </b> ' . $desc . "</li>");
            echo ('<br><li class="list-group-item mt-3 border border-warning"><b>Proprietário: </b>' . $prop . "</li>");
            echo ('<br><li class="list-group-item mt-3 mb-3 border border-warning"><b>Data do Cadastramento: </b>' . $datacad . "</li>");
            echo ('<button class="btn btn-warning mb-3"><a href="index.html" class="bruh">Voltar</a></button>');
            echo ('</div>');
        }

    ?>

    
</body>

</html>